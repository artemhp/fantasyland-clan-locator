export class Hero {
  id: number;
  name: string;
  status: boolean;
  location1: string;
  location2: string;
  combat: number;
  date: any;
  level: number;
  color: string;
  style: string;
  guild: any;
  gender: string;
}
