System.register(['angular2/core', 'angular2/http', 'rxjs/Observable'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, Observable_1;
    var HeroLocationService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (Observable_1_1) {
                Observable_1 = Observable_1_1;
            }],
        execute: function() {
            HeroLocationService = (function () {
                function HeroLocationService(http) {
                    this.http = http;
                    this._locationUrl = 'http://fantasyland.ru/cgi/technical_place_list.php'; // URL to web api
                    this._roomUrl = 'http://fantasyland.ru/cgi/technical_loc_list.php'; // URL to web api
                    this.storageLocation = {};
                    this.storageRoom = {};
                }
                HeroLocationService.prototype.getLocations = function () {
                    return this.http.get(this._locationUrl)
                        .map(this.extracLocation)
                        .catch(this.handleError);
                };
                HeroLocationService.prototype.getRoom = function () {
                    return this.http.get(this._roomUrl)
                        .map(this.extracRoom)
                        .catch(this.handleError);
                };
                HeroLocationService.prototype.extracLocation = function (res) {
                    if (res.status < 200 || res.status >= 300) {
                        throw new Error('Bad response status: ' + res.status);
                    }
                    var myString = res.text();
                    var resultSplit = {};
                    var splits = myString.split(/([0-9]*\s[а-яА-Я- ]*)/gi);
                    splits.map(function (el) {
                        if (el) {
                            var myRegexp1 = /^([0-9]*)\s([а-яА-Я- ]*)$/gi;
                            var match7 = myRegexp1.exec(el.trim());
                            resultSplit[match7[1]] = match7[2];
                        }
                    });
                    return resultSplit;
                };
                HeroLocationService.prototype.extracRoom = function (res) {
                    if (res.status < 200 || res.status >= 300) {
                        throw new Error('Bad response status: ' + res.status);
                    }
                    var myString = res.text();
                    var resultSplit = {};
                    var splits = myString.split(/([0-9]*\s[0-9]*\s[0-9]?[\u0400-\u04FF\a-z\-&; \"\.\:]*)/gi);
                    splits.map(function (el) {
                        if (el) {
                            var myRegexp1 = /([0-9]*)\s([0-9]*)\s([0-9]?[\u0400-\u04FF\a-z\-&; \"\.\:]*)/gi;
                            var match8 = myRegexp1.exec(el.trim());
                            if (match8) {
                                resultSplit[match8[1] + " " + match8[2]] = match8[3].replace("&nbsp;", " ");
                            }
                        }
                    });
                    return resultSplit;
                };
                HeroLocationService.prototype.handleError = function (error) {
                    // In a real world app, we might send the error to remote logging infrastructure
                    var errMsg = error.message || 'Server error';
                    console.error(errMsg); // log to console instead
                    return Observable_1.Observable.throw(errMsg);
                };
                HeroLocationService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], HeroLocationService);
                return HeroLocationService;
            }());
            exports_1("HeroLocationService", HeroLocationService);
        }
    }
});
//# sourceMappingURL=hero-location.service.js.map