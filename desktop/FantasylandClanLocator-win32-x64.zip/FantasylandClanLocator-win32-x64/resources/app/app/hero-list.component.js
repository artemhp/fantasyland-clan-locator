System.register(['angular2/core', './clan.service', './clan-list.service', './hero-location.service', './storage.service', './hero.directive', './hero-location.component', './hero-guild.component', './sortArray.pipe'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, clan_service_1, clan_list_service_1, hero_location_service_1, storage_service_1, hero_directive_1, hero_location_component_1, hero_guild_component_1, sortArray_pipe_1;
    var HeroListComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (clan_service_1_1) {
                clan_service_1 = clan_service_1_1;
            },
            function (clan_list_service_1_1) {
                clan_list_service_1 = clan_list_service_1_1;
            },
            function (hero_location_service_1_1) {
                hero_location_service_1 = hero_location_service_1_1;
            },
            function (storage_service_1_1) {
                storage_service_1 = storage_service_1_1;
            },
            function (hero_directive_1_1) {
                hero_directive_1 = hero_directive_1_1;
            },
            function (hero_location_component_1_1) {
                hero_location_component_1 = hero_location_component_1_1;
            },
            function (hero_guild_component_1_1) {
                hero_guild_component_1 = hero_guild_component_1_1;
            },
            function (sortArray_pipe_1_1) {
                sortArray_pipe_1 = sortArray_pipe_1_1;
            }],
        execute: function() {
            HeroListComponent = (function () {
                function HeroListComponent(_heroService, _heroLocationService, _storageService) {
                    this._heroService = _heroService;
                    this._heroLocationService = _heroLocationService;
                    this._storageService = _storageService;
                    this.clanList = [];
                    this.model = {
                        clan: 3
                    };
                    this.roomStatus = false;
                    this.locationStatus = false;
                }
                HeroListComponent.prototype.clanChange = function () {
                    this.getHeroes(this.model.clan);
                };
                HeroListComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    this.getHeroes(this.model.clan);
                    this.clanList = this._storageService.clans;
                    this._heroLocationService.getLocations()
                        .subscribe(function (locations) { _this._storageService.locations = locations; _this.locationStatus = true; }, function (error) { _this.errorMessage = error; });
                    this._heroLocationService.getRoom()
                        .subscribe(function (rooms) { _this._storageService.rooms = rooms; _this.roomStatus = true; }, function (error) { _this.errorMessage = error; });
                };
                HeroListComponent.prototype.getHeroes = function (el) {
                    var _this = this;
                    this._heroService.getHeroes(el).subscribe(function (heroes) { _this.heroes = heroes; }, function (error) { _this.errorMessage = error; });
                };
                HeroListComponent.prototype.showDIff = function (el) {
                    if (this.heroes[el]) {
                        var a = this.heroes[el].date;
                        var b = moment();
                        return b.diff(a, 'days'); // 86400000;
                    }
                    else {
                        return 10000000;
                    }
                };
                HeroListComponent = __decorate([
                    core_1.Component({
                        selector: 'hero-list',
                        templateUrl: 'app/hero-list.component.html',
                        styles: ['.error {color:red;}'],
                        providers: [clan_service_1.HeroService, clan_list_service_1.ClanListService, hero_location_service_1.HeroLocationService],
                        directives: [hero_directive_1.HeroStyleDirective, hero_location_component_1.HeroLocationComponent, hero_guild_component_1.HeroGuildComponent],
                        pipes: [sortArray_pipe_1.SortArray]
                    }), 
                    __metadata('design:paramtypes', [clan_service_1.HeroService, hero_location_service_1.HeroLocationService, storage_service_1.StorageService])
                ], HeroListComponent);
                return HeroListComponent;
            }());
            exports_1("HeroListComponent", HeroListComponent);
        }
    }
});
//# sourceMappingURL=hero-list.component.js.map