System.register(['angular2/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var StorageService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            StorageService = (function () {
                function StorageService() {
                    this.clans = [
                        { id: 1, name: 'LDK' },
                        { id: 3, name: 'Союз Древних' },
                        { id: 136, name: "The Legends" },
                        { id: 65, name: "Хранители Вечности" },
                        { id: 129, name: "S i n" },
                        { id: 10, name: 'Орден Равновесия' },
                        { id: 66, name: 'Sigma' },
                        { id: 109, name: 'Союз Эльфов' },
                        { id: 16, name: 'Хранители Света' },
                        { id: 194, name: 'The Shades' },
                        { id: 13, name: 'Орден Рассвета' },
                        { id: 62, name: 'Рассвет Новой Эры' },
                        { id: 148, name: 'Братство Славян' },
                        { id: 127, name: 'Мафия' },
                        { id: 54, name: 'Гвардия Света' },
                        { id: 33, name: 'Рыцыри Арки' },
                        { id: 161, name: 'Серые стражи' },
                        { id: 141, name: 'Хранители Тьмы' },
                        { id: 41, name: 'Vega' },
                        { id: 139, name: 'Орден Меча и Магии' },
                        { id: 153, name: 'Хранители Энии' },
                        { id: 176, name: 'Sin`s Tiro' },
                        { id: 78, name: 'Орда Окров' },
                        { id: 59, name: 'Академия Древних' },
                        { id: 46, name: 'Служители Храма' },
                        { id: 137, name: 'Resente Lim' },
                        { id: 192, name: 'Рыцари круглого стола' },
                        { id: 149, name: 'Рекруты' },
                        { id: 169, name: 'Дикие Орки' },
                        { id: 164, name: 'Орден Восходящего Солнца' },
                        { id: 174, name: 'Созвездие Славян' },
                        { id: 113, name: 'Гильдия Художников' },
                        { id: 42, name: 'Знак Грома' },
                        { id: 204, name: 'Орден Пылающих Драконов' },
                    ];
                }
                StorageService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [])
                ], StorageService);
                return StorageService;
            }());
            exports_1("StorageService", StorageService);
        }
    }
});
//# sourceMappingURL=storage.service.js.map