System.register(['angular2/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var UiFunctions;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            UiFunctions = (function () {
                function UiFunctions() {
                    this._ids2 = new Array(1, 4, 3, 6, 7, 8, 10, 13, 11, 12, 15, 16, 18, 21, 28, 33, 42, 41, 46, 70, 54, 59, 204, 62, 148, 65, 66, 68, 78, 136, 109, 149, 113, 127, 129, 161, 137, 139, 141, 153, 176, 164, 169, 200, 174, 194, 192);
                    this._imgs = new Array('creators_small.gif', 'miners_capital_small.gif', 'ancient_union_small.gif', 'thinkers_small.gif', 'fighters_small.gif', 'hunters_small.gif', 'balance_small.gif', 'dawn_small.gif', 'smith_capital_small.gif', 'jewelry_small.gif', 'tailors_small.gif', 'lightkeepers_small.gif', 'druids_small.gif', 'guard_small.gif', 'alchemists_small.gif', 'kark.gif', 'vega2.gif', 'vega.gif', 'hram.gif', 'merch_small.gif', '0007.gif', 'ancient_akademy_small.gif', 'opd2.gif', 'rassvnovera.gif', 'bsl.gif', 'etern_keepers.gif', 'sd14.GIF', 'teachers.gif', 'horde_small1.gif', 'legends.gif', 'elfunion1.gif', 'recruits_small.gif', 'painter.gif', 'mafia2.gif', 'sin.gif', 'gray_guard.gif', 'resentelim.gif', 'oda.gif', 'DarkKeepers2.gif', 'nasledniki.gif', 'sinstrio.gif', 'rassvet2.gif', 'wildorks.gif', 'labers_small.gif', 'ss.gif', 'shades.gif', 'rks3.gif');
                }
                UiFunctions.prototype.showGuildImg = function (id) {
                    var showIcon = "";
                    this._ids2.map(function (el, index) {
                        if (el == id) {
                            showIcon = "http://fantasyland.ru/images/clans/" + this._imgs[index];
                        }
                    }, this);
                    return showIcon;
                };
                UiFunctions = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [])
                ], UiFunctions);
                return UiFunctions;
            }());
            exports_1("UiFunctions", UiFunctions);
        }
    }
});
//# sourceMappingURL=ui-functions.service.js.map